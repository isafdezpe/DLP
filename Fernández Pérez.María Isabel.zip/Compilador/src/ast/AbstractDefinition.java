/**
 * @generated VGen (for ANTLR) 1.7.0
 */

package ast;

public abstract class AbstractDefinition extends AbstractAST implements Definition {

    protected int address;

    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }
}
