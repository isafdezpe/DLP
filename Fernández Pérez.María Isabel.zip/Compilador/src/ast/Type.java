/**
 * @generated VGen (for ANTLR) 1.7.0
 */

package ast;

public interface Type extends AST {

    public int getSize();

    public char getSuffix();

    public String getMAPLName();

}
