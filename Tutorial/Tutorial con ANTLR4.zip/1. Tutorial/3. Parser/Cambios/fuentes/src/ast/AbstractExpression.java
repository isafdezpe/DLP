/**
 * @generated VGen (for ANTLR) 1.7.1
 */

package ast;

public abstract class AbstractExpression extends AbstractAST implements Expression {

}
