package visitor;

/**
 *  Esta clase se completará en la fase de Análisis Sintáctico.
 */

public interface Visitor {
    // public Object visit(Programa node, Object param);
}
